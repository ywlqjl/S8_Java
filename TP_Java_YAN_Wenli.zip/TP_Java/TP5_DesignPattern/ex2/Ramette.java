package ex2;

public class Ramette extends Article {
	

	private Double grammage;
	
	public Ramette() {
		// TODO Auto-generated constructor stub
	}

	public Double getGrammage() {
		return grammage;
	}

	public void setGrammage(Double grammage) {
		this.grammage = grammage;
	}

	
}
