package ex2;

public class Stylo extends Article {


	private String couleur;
	
	public Stylo() {
		// TODO Auto-generated constructor stub
	}

	public String getCouleur() {
		return couleur;
	}

	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}


	
	

}
