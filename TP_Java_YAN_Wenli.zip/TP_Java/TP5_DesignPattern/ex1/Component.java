package ex1;

public interface Component {

	//Ce sont des methodes common entre des figures (composites) et ses filles (simples)
	public void tranlater();
	public void dessiner();
	
}
