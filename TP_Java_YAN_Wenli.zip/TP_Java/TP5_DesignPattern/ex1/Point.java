package ex1;

public class Point extends Objet {

	public Point() {
		// TODO Auto-generated constructor stub
	}



	@Override
	public void tranlater() {
		System.out.println("Afficher un point");
		
	}

	@Override
	public void dessiner() {
		System.out.println("Dessiner un point");
		
	}
}
