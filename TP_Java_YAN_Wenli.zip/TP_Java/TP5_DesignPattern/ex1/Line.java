package ex1;

public class Line extends Objet {

	public Line() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public void tranlater() {
		System.out.println("Afficher un line");
		
	}

	@Override
	public void dessiner() {
		System.out.println("Dessiner un line");
	}

	
}
