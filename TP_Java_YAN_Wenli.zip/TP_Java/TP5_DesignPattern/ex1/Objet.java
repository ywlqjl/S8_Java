package ex1;
//parent
public abstract class Objet {

	public Objet() {
	}

	public void tranlater() {
	}
	
	public void dessiner() {
	}

}
