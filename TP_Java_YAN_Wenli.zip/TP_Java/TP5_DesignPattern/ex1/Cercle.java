package ex1;

public class Cercle extends Figure{

	public Cercle() {
		// TODO Auto-generated constructor stub
	}



	@Override
	public void tranlater() {
		System.out.println("Afficher un cercle");
		
	}

	@Override
	public void dessiner() {
		System.out.println("Dessiner un cercle");

		
	}


}
