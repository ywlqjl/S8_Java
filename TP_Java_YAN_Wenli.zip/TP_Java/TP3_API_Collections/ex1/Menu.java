package ex1;

public class Menu {


	/**
	 * Show the items of the menu
	 */
	public void showMenu(){
		    System.out.println("================== Menu ================"); 
			System.out.println("1:Add a note\n"+"2:Modify a note\n"+"3:Show ALl Notes\n"+"4:Average\n"+"5:Exit"); 
		    System.out.println("========================================"); 
		    System.out.println("Your choice:"); 
	}
}
