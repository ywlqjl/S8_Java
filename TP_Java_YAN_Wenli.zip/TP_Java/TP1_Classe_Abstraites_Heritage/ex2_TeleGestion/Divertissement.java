package ex2_TeleGestion;

public class Divertissement extends Emission {

	public Divertissement() {
		super();
	}
	
	public Divertissement(String name, int duree) {
		super(name, 2);
	}


}
