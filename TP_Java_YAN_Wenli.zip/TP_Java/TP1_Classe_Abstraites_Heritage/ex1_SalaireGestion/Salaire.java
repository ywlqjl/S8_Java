package ex1_SalaireGestion;

public interface Salaire {

	public double getSalaire();
	public void setInfoSalaire();//参数？
}
